<?php
/**
 * Plugin Name:       EVERMOD Chat
 * Plugin URI:         https://www.evermod.eu
 * Description:        Embedded EVERMOD AI chat section (Orion) with instant quick answers (fast lane, served in ~1s) and AI replies for everything else. Also provides the [evermod_thankyou] shortcode. Settings under "EVERMOD Chat" in the admin menu.
 * Version:            2.6.3
 * Author:             EVERMOD
 * Author URI:         https://www.evermod.eu
 * License:            GPL-2.0-or-later
 * Text Domain:        evermod-chat
 */

// No direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'EVERMOD_CHAT_VERSION', '2.6.3' );
define( 'EVERMOD_CHAT_URL', plugin_dir_url( __FILE__ ) );

/**
 * Defaults for settings.
 */
function evermod_chat_defaults() {
	return array(
		'meeting_link'  => 'https://meetings-eu1.hubspot.com/normunds-broks/schedule-google-meets-call-with-normunds-evermod', // Book a Video Call — HubSpot link (opened in a new tab).
		'callback_phone' => '', // Request a Call Back — phone number shown to visitors.
		'callback_text' => 'Please call me back', // Predefined WhatsApp message for Request a Call Back.
	);
}

/**
 * Load the chat widget on every frontend page + pass settings to JS.
 */
function evermod_chat_enqueue_widget() {
	wp_enqueue_script(
		'evermod-chat-widget',
		EVERMOD_CHAT_URL . 'assets/widget.js',
		array(),
		EVERMOD_CHAT_VERSION,
		true // footer.
	);

	$defaults = evermod_chat_defaults();
	wp_localize_script(
		'evermod-chat-widget',
		'EVERMOD_CHAT_CONFIG',
		array(
			'meetingLink'   => get_option( 'evermod_chat_meeting_link', $defaults['meeting_link'] ),
			'callbackPhone' => get_option( 'evermod_chat_callback_phone', $defaults['callback_phone'] ),
			'callbackText'  => get_option( 'evermod_chat_callback_text', $defaults['callback_text'] ),
			'whatsappNumber' => '37127034348',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'evermod_chat_enqueue_widget' );

/**
 * Defer the widget script.
 */
function evermod_chat_defer_script( $tag, $handle ) {
	if ( 'evermod-chat-widget' === $handle ) {
		return str_replace( ' src', ' defer src', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'evermod_chat_defer_script', 10, 2 );

/* -------------------------------------------------------------------------
 * ADMIN: "EVERMOD Chat" menu with settings
 * ---------------------------------------------------------------------- */

function evermod_chat_register_settings() {
	register_setting( 'evermod_chat_settings', 'evermod_chat_meeting_link', array(
		'type'              => 'string',
		'sanitize_callback' => 'esc_url_raw',
		'default'           => '',
	) );
	register_setting( 'evermod_chat_settings', 'evermod_chat_callback_phone', array(
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_text_field',
		'default'           => '',
	) );
	register_setting( 'evermod_chat_settings', 'evermod_chat_callback_text', array(
		'type'              => 'string',
		'sanitize_callback' => 'sanitize_textarea_field',
		'default'           => evermod_chat_defaults()['callback_text'],
	) );
}
add_action( 'admin_init', 'evermod_chat_register_settings' );

function evermod_chat_admin_menu() {
	add_menu_page(
		'EVERMOD Chat',
		'EVERMOD Chat',
		'manage_options',
		'evermod-chat',
		'evermod_chat_settings_page',
		'dashicons-format-chat',
		58
	);
}
add_action( 'admin_menu', 'evermod_chat_admin_menu' );

function evermod_chat_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$defaults = evermod_chat_defaults();
	?>
	<div class="wrap">
		<h1>EVERMOD Chat</h1>
		<p>Settings for the fixed chat window and its quick-action buttons. The window appears on every page, bottom-right, always visible.</p>
		<form method="post" action="options.php">
			<?php settings_fields( 'evermod_chat_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="evermod_chat_meeting_link">Book a Video Call — meeting link</label></th>
					<td>
						<input type="url" id="evermod_chat_meeting_link" name="evermod_chat_meeting_link"
							value="<?php echo esc_attr( get_option( 'evermod_chat_meeting_link', $defaults['meeting_link'] ) ); ?>"
							class="regular-text" placeholder="https://app.hubspot.com/meetings/..." />
						<p class="description">Custom link (e.g. HubSpot meetings page). The "Book a Video Call" button opens this link in a new tab. If empty, the button sends a booking request to Orion in the chat instead.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="evermod_chat_callback_phone">Request a Call Back — phone number</label></th>
					<td>
						<input type="text" id="evermod_chat_callback_phone" name="evermod_chat_callback_phone"
							value="<?php echo esc_attr( get_option( 'evermod_chat_callback_phone', $defaults['callback_phone'] ) ); ?>"
							class="regular-text" placeholder="+371 27034348" />
						<p class="description">Shown to visitors as a direct dial option in the chat window. If empty, no phone is shown.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="evermod_chat_callback_text">Request a Call Back — predefined message</label></th>
					<td>
						<textarea id="evermod_chat_callback_text" name="evermod_chat_callback_text"
							rows="3" class="large-text"><?php echo esc_textarea( get_option( 'evermod_chat_callback_text', $defaults['callback_text'] ) ); ?></textarea>
						<p class="description">Opens WhatsApp (wa.me/37127034348) with this text pre-filled in the message box when a visitor presses "Request a Call Back".</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * Shortcode: [evermod_thankyou]
 * Warm "Inquiry Received" thank-you sheet per approved design preview:
 * What's Next options + embedded Orion chat section (hero lives in the page blocks)
 * + lead-in. The chat renders inside #evermod-chat.
 * ---------------------------------------------------------------------- */

function evermod_chat_thankyou_shortcode() {
	ob_start();
?>
<div class="evm-ty-wrap">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wght@700;800&family=Work+Sans:wght@400;500;600;700&display=swap">
<style>
  :root { --page-bg: #f6efe4;
    --card-bg: #fff2df;
    --strip-bg: #f3ebe1;
    --tan: #dccfc4;
    --ink: #2a241a;
    --ink-soft: #6b5f50;
    --line: #e8ddd4;
    --green: #4a7c5f;
    --rust: #c8915a;
    --coral: #f68989;
    --btn: #1a1a1a;
    --btn-ink: #f6efe4;
    --white: #ffffff; }
  .evm-ty-wrap * { box-sizing: border-box; }
  .evm-ty-wrap body { margin: 0;
    background: var(--page-bg);
    color: var(--ink);
    font-family: "Work Sans", ui-sans-serif, system-ui, sans-serif;
    padding: 32px 16px 64px;
    display: flex;
    justify-content: center; }
  .evm-ty-wrap h1, .evm-ty-wrap h2, .evm-ty-wrap h3, .evm-ty-wrap .display { font-family: "Archivo", ui-sans-serif, system-ui, sans-serif; }
  .evm-ty-wrap { width: 100%; max-width: 820px; margin-left: auto; margin-right: auto; }
  .evm-ty-wrap .sheet { width: 100%; margin-left: auto; margin-right: auto;
    max-width: 760px;
    background: var(--card-bg);
    border-radius: 20px;
    box-shadow: 0 24px 60px -30px rgba(0,0,0,0.35);
    padding: 40px; }
  @media (max-width: 520px) {.evm-ty-wrap .sheet { padding: 24px 18px; border-radius: 16px; }}
  .evm-ty-wrap .section-label { font-weight: 700;
    font-size: 14px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    margin: 0 0 14px; }
  .evm-ty-wrap .options { display: flex;
    flex-direction: column;
    gap: 10px;
    margin-bottom: 20px; }
  .evm-ty-wrap .option { display: flex;
    align-items: center;
    gap: 16px;
    background: var(--white);
    border: 1px solid var(--line);
    border-radius: 10px;
    padding: 18px 20px;
    text-decoration: none;
    color: inherit;
    transition: transform 0.15s ease, box-shadow 0.15s ease;
    cursor: pointer;
    width: 100%;
    text-align: left;
    font-family: inherit; }
  .evm-ty-wrap .option:hover { transform: translateY(-1px); box-shadow: 0 10px 24px -18px rgba(0,0,0,0.4); }
  .evm-ty-wrap .option.green { border-left: 4px solid var(--green); }
  .evm-ty-wrap .option.rust { border-left: 4px solid var(--rust); }
  .evm-ty-wrap .option.coral { border-left: 4px solid var(--coral); }
  .evm-ty-wrap .icon-badge { flex: none;
    width: 48px;
    height: 48px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff; }
  .evm-ty-wrap .icon-badge.green { background: var(--green); }
  .evm-ty-wrap .icon-badge.rust { background: var(--rust); }
  .evm-ty-wrap .icon-badge.coral { background: var(--coral); }
  .evm-ty-wrap .option-title { font-weight: 700; font-size: 16px; margin: 0 0 2px; }
  .evm-ty-wrap .option-text { font-size: 13.5px; color: var(--ink-soft); margin: 0; }
  .evm-ty-wrap .chat-label { color: var(--green); margin-top: 6px; }
  .evm-ty-wrap .chat-sub { font-size: 14px;
    color: var(--ink-soft);
    margin: 0 0 14px; }
  .evm-ty-wrap #evermod-chat { width: 100%; }
  .evm-ty-wrap .lead-in { font-size: 14.5px;
    color: var(--ink-soft);
    margin: 26px 0 28px; }
</style>
  <div class="sheet">
    <div class="options">
      <button class="option green" type="button" onclick="EvermodChat.scrollTo()">
        <div class="icon-badge green">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
        </div>
        <div>
          <p class="option-title">Get Immediate Response</p>
          <p class="option-text">Chat with Orion — instant answers about pricing, availability &amp; floor plans</p>
        </div>
      </button>
      <button class="option rust" type="button" id="evm-opt-video">
        <div class="icon-badge rust">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m23 7-7 5 7 5V7Z"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>
        </div>
        <div>
          <p class="option-title">Book a Video Call</p>
          <p class="option-text">Walk through designs with a specialist from Evermod</p>
        </div>
      </button>
      <a class="option coral" href="https://wa.me/37127034348" target="_blank" rel="noopener">
        <div class="icon-badge coral">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        </div>
        <div>
          <p class="option-title">Request a Call Back</p>
          <p class="option-text">We call you back — no waiting on hold</p>
        </div>
      </a>
    </div>

    <p class="section-label chat-label">+ Ask Orion</p>
    <p class="chat-sub">Our AI assistant is right here in the page — no popups, no buttons to open. Just write your question.</p>
    <div id="evermod-chat"></div>

    <p class="lead-in">Our unique pre-engineered system delivers your home in just 12 weeks — choose an option above to discover how.</p>

  </div>

</div>
<script>
(function(){
  var v = document.getElementById('evm-opt-video');
  if (!v) return;
  v.addEventListener('click', function () {
    var cfg = window.EVERMOD_CHAT_CONFIG || {};
    if (cfg.meetingLink) { window.open(cfg.meetingLink, '_blank'); }
    else { EvermodChat.scrollTo(); EvermodChat.ask('I would like to book a video call with a specialist'); }
  });
})();
</script>
<?php
	return ob_get_clean();
}

add_shortcode( 'evermod_thankyou', 'evermod_chat_thankyou_shortcode' );
